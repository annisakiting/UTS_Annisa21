<?php $__env->startSection('content'); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Detail Pesanan (Nota) #')); ?><?php echo e($order->id); ?>

            </h2>
            
            
            <div>
                
                <button onclick="window.print()" class="print:hidden inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                    Cetak Nota
                </button>
                <a href="<?php echo e(route('pesanan.index')); ?>" class="print:hidden ml-2 inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-25 transition ease-in-out duration-150">
                    Kembali
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    
    <style>
        @media print {
            body {
                background: #fff !important;
            }
            .py-12, .max-w-7xl, .sm\:px-6, .lg\:px-8 {
                padding: 0 !important;
                margin: 0 !important;
                max-width: 100% !important;
            }
            .bg-white {
                border: none !important;
                box-shadow: none !important;
            }
            .print\:text-black {
                color: #000 !important;
            }
        }
    </style>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 md:p-10 text-gray-900 dark:text-gray-100 print:text-black">

                    
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h5 class="text-lg font-bold uppercase">App Penjahit</h5>
                            <p class="text-sm">Jl. Pahlawan Kerja No. 123</p>
                            <p class="text-sm">Telepon: 0812-3456-7890</p>
                        </div>
                        <div class="text-right">
                            <h5 class="text-lg font-bold uppercase">Nota Pesanan</h5>
                            <p class="text-sm"><strong>ID Pesanan:</strong> #<?php echo e($order->id); ?></p>
                            <p class="text-sm"><strong>Tgl Pesan:</strong> <?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d M Y')); ?></p>
                        </div>
                    </div>

                    <hr class="border-gray-300 dark:border-gray-700 my-4">

                    
                    <div class="flex justify-between mb-4">
                        <div>
                            <h6 class="font-semibold">Ditagih Kepada:</h6>
                            <p class="text-sm"><strong><?php echo e($order->customer->name ?? 'N/A'); ?></strong></p>
                            <p class="text-sm"><?php echo e($order->customer->phone_number ?? 'N/A'); ?></p>
                            <p class="text-sm"><?php echo e($order->customer->address ?? 'N/A'); ?></p>
                        </div>
                        <div class="text-right">
                            <h6 class="font-semibold">Info Pesanan:</h6>
                            <p class="text-sm"><strong>Tgl Selesai (Est.):</strong> <?php echo e($order->due_date ? \Carbon\Carbon::parse($order->due_date)->format('d M Y') : '-'); ?></p>
                            <p class="text-sm"><strong>Status:</strong> <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-200 text-gray-800"><?php echo e($order->status); ?></span></p>
                        </div>
                    </div>

                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">No.</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nama Layanan</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Kuantitas</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Harga Satuan</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($loop->iteration); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->service->service_name ?? 'Layanan Dihapus'); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($item->quantity); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap">Rp <?php echo e(number_format($item->price_per_item, 0, ',', '.')); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right">Rp <?php echo e(number_format($item->price_per_item * $item->quantity, 0, ',', '.')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <div class="flex justify-end mt-4">
                        <div class="w-full md:w-1/3">
                            <div class="flex justify-between">
                                <span class="font-semibold">Total Harga</span>
                                <span class="font-semibold">Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></span>
                            </div>
                            <div class="flex justify-between text-gray-600 dark:text-gray-400">
                                <span>Uang Muka (DP)</span>
                                <span>Rp <?php echo e(number_format($order->down_payment, 0, ',', '.')); ?></span>
                            </div>
                            <hr class="border-gray-300 dark:border-gray-700 my-2">
                            <div class="flex justify-between font-bold text-lg">
                                <span>Sisa Bayar</span>
                                <span>Rp <?php echo e(number_format($order->total_price - $order->down_payment, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                    </div>

                    
                    <?php if($order->notes): ?>
                        <hr class="border-gray-300 dark:border-gray-700 my-4">
                        <div>
                            <strong class="font-semibold">Catatan Pesanan:</strong>
                            <p class="text-sm italic text-gray-600 dark:text-gray-400"><?php echo e($order->notes); ?></p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/ferdiboy/Project/aplikasi-penjahit/resources/views/pesanan/show.blade.php ENDPATH**/ ?>