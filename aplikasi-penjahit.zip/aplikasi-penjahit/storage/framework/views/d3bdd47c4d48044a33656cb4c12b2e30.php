<?php $__env->startSection('content'); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Edit Ukuran')); ?>: <?php echo e($measurement->measurement_name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <form action="<?php echo e(route('ukuran.update', $measurement->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-4">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <label for="measurement_name" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Nama Ukuran*</label>
                        <input type="text" 
                               id="measurement_name" 
                               name="measurement_name" 
                               value="<?php echo e(old('measurement_name', $measurement->measurement_name)); ?>"
                               required
                               class="mt-1 block w-full md:w-1/2 border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm <?php $__errorArgs = ['measurement_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['measurement_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-4">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <h3 class="text-lg font-medium mb-4">Ukuran Atasan (Kemeja, Baju, dll)</h3>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                                <label for="lingkar_dada" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Lingkar Dada (cm)</label>
                                <input type="number" step="any" name="lingkar_dada" value="<?php echo e(old('lingkar_dada', $measurement->details['lingkar_dada'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label for="panjang_lengan" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Panjang Lengan (cm)</label>
                                <input type="number" step="any" name="panjang_lengan" value="<?php echo e(old('panjang_lengan', $measurement->details['panjang_lengan'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label for="lebar_bahu" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Lebar Bahu (cm)</label>
                                <input type="number" step="any" name="lebar_bahu" value="<?php echo e(old('lebar_bahu', $measurement->details['lebar_bahu'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label for="panjang_baju" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Panjang Baju (cm)</label>
                                <input type="number" step="any" name="panjang_baju" value="<?php echo e(old('panjang_baju', $measurement->details['panjang_baju'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg mb-4">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        <h3 class="text-lg font-medium mb-4">Ukuran Bawahan (Celana, Rok, dll)</h3>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                                <label for="lingkar_pinggang" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Lingkar Pinggang (cm)</label>
                                <input type="number" step="any" name="lingkar_pinggang" value="<?php echo e(old('lingkar_pinggang', $measurement->details['lingkar_pinggang'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label for="lingkar_panggul" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Lingkar Panggul (cm)</label>
                                <input type="number" step="any" name="lingkar_panggul" value="<?php echo e(old('lingkar_panggul', $measurement->details['lingkar_panggul'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label for="panjang_celana" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Panjang Celana/Rok (cm)</label>
                                <input type="number" step="any" name="panjang_celana" value="<?php echo e(old('panjang_celana', $measurement->details['panjang_celana'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label for="lingkar_paha" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Lingkar Paha (cm)</label>
                                <input type="number" step="any" name="lingkar_paha" value="<?php echo e(old('lingkar_paha', $measurement->details['lingkar_paha'] ?? '')); ?>" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex items-center justify-end mt-4">
                    <a href="<?php echo e(route('pelanggan.ukuran.index', $measurement->customer_id)); ?>" class="mr-4 text-gray-600 dark:text-gray-400 hover:text-gray-900">
                        Batal
                    </a>
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/ferdiboy/Project/aplikasi-penjahit/resources/views/ukuran/edit.blade.php ENDPATH**/ ?>